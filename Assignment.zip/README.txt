Here I have used the 7�1 pattern (7 folders, 1 file), is a widely-adopted structure 
that serves as a basis for large projects. You have all your partials organised into 7 different 
folders, and a single file sits at the root level (App.scss) to handle the 
imports � which is the file you compile into CSS (App.css).
#If some folders are not required from 7�1 pattern (7 folders, 1 file), then we can 
delete them from structure.

